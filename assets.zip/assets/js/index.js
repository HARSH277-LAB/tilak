const express = require('express');
const app = express;
const router = express.Router();
const controller = require('./form');
const mongoose = require('mongoose');
var connectionURL = 'mongodb+srv://Sameer:Sameer@1482@cluster0.bfmjfti.mongodb.net/?retryWrites=true&w=majority';
mongoose.connect(connectionURL,{useNewUrlParser:true,useUnifiedTopology:true},(err)=>{
    if(err){
        throw err;
    }
    console.log('connected')

})

// app.get("www.google.com",(req,res)=>{
//     res.send("Hello")
// })

// const port = process.env.PORT  || 4000
// app.listen(port,()=>{
//     console.log(`Listening to Port ${port}`)
// })

router.get('/', controller.form);
router.post('/', controller.formprocess);
module.exports = router